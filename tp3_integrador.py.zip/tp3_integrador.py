#Ejerciocio 1
print("=== CAJA DEL KIOSCO ===")


nombre = input("Nombre del cliente: ")

while not nombre.isalpha():
    print("Error: ingrese solo letras.")
    nombre = input("Nombre del cliente: ")


cantidad = input("Cantidad de productos: ")

while not cantidad.isdigit() or int(cantidad) <= 0:
    print("Error: ingrese un número entero positivo.")
    cantidad = input("Cantidad de productos: ")

cantidad = int(cantidad)

total_sin_descuentos = 0
total_con_descuentos = 0

for i in range(1, cantidad + 1):

    precio = input("Producto " + str(i) + " - Precio: ")

    while not precio.isdigit():
        print("Error: ingrese un precio válido.")
        precio = input("Producto " + str(i) + " - Precio: ")

    precio = int(precio)

    descuento = input("¿Tiene descuento? (S/N): ")

    while descuento.lower() != "s" and descuento.lower() != "n":
        print("Error: ingrese S o N.")
        descuento = input("¿Tiene descuento? (S/N): ")

    total_sin_descuentos = total_sin_descuentos + precio

    if descuento.lower() == "s":
        precio_con_descuento = precio * 0.90
        total_con_descuentos = total_con_descuentos + precio_con_descuento
    else:
        total_con_descuentos = total_con_descuentos + precio

ahorro = total_sin_descuentos - total_con_descuentos
promedio = float(total_con_descuentos) / cantidad

print()
print("Cliente:", nombre)
print("Cantidad de productos:", cantidad)
print("Total sin descuentos: $", total_sin_descuentos)
print(f"Total con descuentos: ${total_con_descuentos:.2f}")
print(f"Ahorro: ${ahorro:.2f}")
print(f"Promedio por producto: ${promedio:.2f}")

#Ejerciocio 2

usuario_correcto = "alumno"
clave_correcta = "python123"

intentos = 0
acceso = False


while intentos < 3 and acceso == False:
    intentos = intentos + 1
    print("")
    usuario = input("Intento " + str(intentos) + "/3 - Usuario: ")
    clave = input("Clave: ")

    if usuario == usuario_correcto and clave == clave_correcta:
        acceso = True
        print("Acceso concedido.")
    else:
        print("Error: credenciales invalidas.")

if acceso == False:
    print("")
    print("Cuenta bloqueada.")
else:
    
    salir = False
    while salir == False:
        print("")
        print("1) Estado   2) Cambiar clave   3) Mensaje   4) Salir")
        opcion = input("Opcion: ")
        
#Ejercicio 3

lunes1 = ""
lunes2 = ""
lunes3 = ""
lunes4 = ""

martes1 = ""
martes2 = ""
martes3 = ""


operador = input("Nombre del operador: ")
while operador.isalpha() == False:
    print("Error: solo se permiten letras.")
    operador = input("Nombre del operador: ")

print("Bienvenido/a " + operador + ".")

cerrar = False
while cerrar == False:
    print("")
    print("--- MENU ---")
    print("1) Reservar turno")
    print("2) Cancelar turno")
    print("3) Ver agenda del dia")
    print("4) Ver resumen general")
    print("5) Cerrar sistema")

    opcion = input("Opcion: ")
    while opcion.isdigit() == False:
        print("Error: ingrese un numero valido.")
        opcion = input("Opcion: ")

    opcion_numero = int(opcion)
    while opcion_numero < 1 or opcion_numero > 5:
        print("Error: opcion fuera de rango.")
        opcion = input("Opcion: ")
        while opcion.isdigit() == False:
            print("Error: ingrese un numero valido.")
            opcion = input("Opcion: ")
        opcion_numero = int(opcion)

    if opcion_numero == 1:
        dia = input("Dia (1=Lunes, 2=Martes): ")
        while dia.isdigit() == False or (int(dia) != 1 and int(dia) != 2):
            print("Error: elija 1 o 2.")
            dia = input("Dia (1=Lunes, 2=Martes): ")
        dia_numero = int(dia)

        paciente = input("Nombre del paciente: ")
        while paciente.isalpha() == False:
            print("Error: solo se permiten letras.")
            paciente = input("Nombre del paciente: ")

        if dia_numero:
        
            if paciente == lunes1 or paciente == lunes2 or paciente == lunes3 or paciente == lunes4:
                print("Error: ese paciente ya tiene turno el Lunes.")
            else:
                
                if lunes1 == "":
                    lunes1 = paciente
                    print("Turno reservado: Lunes - Turno 1")
                elif lunes2 == "":
                    lunes2 = paciente
                    print("Turno reservado: Lunes - Turno 2")
                elif lunes3 == "":
                    lunes3 = paciente
                    print("Turno reservado: Lunes - Turno 3")
                elif lunes4 == "":
                    lunes4 = paciente
                    print("Turno reservado: Lunes - Turno 4")
                else:
                    print("No hay cupos disponibles el Lunes.")
        else:
            if paciente == martes1 or paciente == martes2 or paciente == martes3:
                print("Error: ese paciente ya tiene turno el Martes.")
            else:
                if martes1 == "":
                    martes1 = paciente
                    print("Turno reservado: Martes - Turno 1")
                elif martes2 == "":
                    martes2 = paciente
                    print("Turno reservado: Martes - Turno 2")
                elif martes3 == "":
                    martes3 = paciente
                    print("Turno reservado: Martes - Turno 3")
                else:
                    print("No hay cupos disponibles el Martes.")

    
    elif opcion_numero == 2:
        dia = input("Dia (1=Lunes, 2=Martes): ")
        while dia.isdigit() == False or (int(dia) != 1 and int(dia) != 2):
            print("Error: elija 1 o 2.")
            dia = input("Dia (1=Lunes, 2=Martes): ")
        dia_numero = int(dia)

        paciente = input("Nombre del paciente: ")
        while paciente.isalpha() == False:
            print("Error: solo se permiten letras.")
            paciente = input("Nombre del paciente: ")

        if dia_numero == 1:
            if paciente == lunes1:
                lunes1 = ""
                print("Turno cancelado (Lunes - Turno 1).")
            elif paciente == lunes2:
                lunes2 = ""
                print("Turno cancelado (Lunes - Turno 2).")
            elif paciente == lunes3:
                lunes3 = ""
                print("Turno cancelado (Lunes - Turno 3).")
            elif paciente == lunes4:
                lunes4 = ""
                print("Turno cancelado (Lunes - Turno 4).")
            else:
                print("Ese paciente no tiene turno el Lunes.")
        else:
            if paciente == martes1:
                martes1 = ""
                print("Turno cancelado (Martes - Turno 1).")
            elif paciente == martes2:
                martes2 = ""
                print("Turno cancelado (Martes - Turno 2).")
            elif paciente == martes3:
                martes3 = ""
                print("Turno cancelado (Martes - Turno 3).")
            else:
                print("Ese paciente no tiene turno el Martes.")

    
    elif opcion_numero == 3:
        dia = input("Dia (1=Lunes, 2=Martes): ")
        while dia.isdigit() == False or (int(dia) != 1 and int(dia) != 2):
            print("Error: elija 1 o 2.")
            dia = input("Dia (1=Lunes, 2=Martes): ")
        dia_numero = int(dia)

        if dia_numero == 1:
            print("--- AGENDA LUNES ---")
            if lunes1 == "":
                print("Turno 1: (libre)")
            else:
                print("Turno 1: " + lunes1)
            if lunes2 == "":
                print("Turno 2: (libre)")
            else:
                print("Turno 2: " + lunes2)
            if lunes3 == "":
                print("Turno 3: (libre)")
            else:
                print("Turno 3: " + lunes3)
            if lunes4 == "":
                print("Turno 4: (libre)")
            else:
                print("Turno 4: " + lunes4)
        else:
            print("--- AGENDA MARTES ---")
            if martes1 == "":
                print("Turno 1: (libre)")
            else:
                print("Turno 1: " + martes1)
            if martes2 == "":
                print("Turno 2: (libre)")
            else:
                print("Turno 2: " + martes2)
            if martes3 == "":
                print("Turno 3: (libre)")
            else:
                print("Turno 3: " + martes3)

    
    elif opcion_numero == 4:
        ocupados_lunes = 0
        if lunes1 != "":
            ocupados_lunes = ocupados_lunes + 1
        if lunes2 != "":
            ocupados_lunes = ocupados_lunes + 1
        if lunes3 != "":
            ocupados_lunes = ocupados_lunes + 1
        if lunes4 != "":
            ocupados_lunes = ocupados_lunes + 1

        ocupados_martes = 0
        if martes1 != "":
            ocupados_martes = ocupados_martes + 1
        if martes2 != "":
            ocupados_martes = ocupados_martes + 1
        if martes3 != "":
            ocupados_martes = ocupados_martes + 1

        libres_lunes = 4 - ocupados_lunes
        libres_martes = 3 - ocupados_martes

        print("--- RESUMEN GENERAL ---")
        print("Lunes: " + str(ocupados_lunes) + " ocupados / " + str(libres_lunes) + " disponibles")
        print("Martes: " + str(ocupados_martes) + " ocupados / " + str(libres_martes) + " disponibles")

        if ocupados_lunes > ocupados_martes:
            print("Dia con mas turnos: Lunes")
        elif ocupados_martes > ocupados_lunes:
            print("Dia con mas turnos: Martes")
        else:
            print("Empate entre Lunes y Martes")

    
    else:
        print("Cerrando sistema. Hasta luego " + operador + ".")
        cerrar = True
        
#Ejercicio 4 

energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""

bloqueado = False
forzadas_seguidas = 0 

print("=== ESCAPE ROOM: LA BOVEDA ===")


agente = input("Nombre del agente: ")
while agente.isalpha() == False:
    print("Error: solo se permiten letras.")
    agente = input("Nombre del agente: ")

print("Agente " + agente + ", tenes que abrir 3 cerraduras.")


while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and bloqueado == False:
    print("")
    print("--- ESTADO ---")
    print("Energia: " + str(energia) + " | Tiempo: " + str(tiempo) + " | Cerraduras: " + str(cerraduras_abiertas) + "/3")
    print("Alarma: " + str(alarma) + " | Codigo parcial: " + codigo_parcial)
    print("1) Forzar cerradura (-20 energia, -2 tiempo)")
    print("2) Hackear panel (-10 energia, -3 tiempo)")
    print("3) Descansar (+15 energia, -1 tiempo)")

    opcion = input("Accion: ")
    while opcion.isdigit() == False:
        print("Error: ingrese un numero valido.")
        opcion = input("Accion: ")

    accion = int(opcion)
    while accion < 1 or accion > 3:
        print("Error: opcion fuera de rango.")
        opcion = input("Accion: ")
        while opcion.isdigit() == False:
            print("Error: ingrese un numero valido.")
            opcion = input("Accion: ")
        accion = int(opcion)

    
    if accion == 1:
        energia = energia - 20
        tiempo = tiempo - 2
        forzadas_seguidas = forzadas_seguidas + 1

        if forzadas_seguidas == 3:
            print("La cerradura se trabo por forzarla 3 veces seguidas. ¡ALARMA ACTIVADA!")
            alarma = True
            forzadas_seguidas = 0
        else:
            if energia < 40:
                print("Poca energia: riesgo de alarma. Elegi un numero del 1 al 3.")
                numero = input("Numero (1-3): ")
                while numero.isdigit() == False or int(numero) < 1 or int(numero) > 3:
                    print("Error: ingrese un numero del 1 al 3.")
                    numero = input("Numero (1-3): ")
                if int(numero) == 3:
                    alarma = True
                    print("¡Mala suerte! Se activo la alarma.")

            if alarma == False:
                cerraduras_abiertas = cerraduras_abiertas + 1
                print("Forzaste la cerradura. Abiertas: " + str(cerraduras_abiertas) + "/3")
            else:
                print("Con la alarma sonando no lograste abrir la cerradura.")

    
    elif accion == 2:
        energia = energia - 10
        tiempo = tiempo - 3
        forzadas_seguidas = 0  

        print("Hackeando el panel...")
        for paso in range(4):
            codigo_parcial = codigo_parcial + "A"
            print("Paso " + str(paso + 1) + "/4 - codigo: " + codigo_parcial)

        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas = cerraduras_abiertas + 1
            print("El codigo es largo y una cerradura se abrio sola. Abiertas: " + str(cerraduras_abiertas) + "/3")

    
    else:
        forzadas_seguidas = 0
        energia = energia + 15
        if energia > 100:
            energia = 100
        tiempo = tiempo - 1

        if alarma == True:
            energia = energia - 10
            print("Descansas, pero la alarma te pone nervioso (-10 energia extra).")
        else:
            print("Descansaste y recuperaste energia.")

    
    if alarma == True and tiempo <= 3 and cerraduras_abiertas < 3:
        bloqueado = True


print("")
print("=== FIN DEL JUEGO ===")
if cerraduras_abiertas == 3:
    print("VICTORIA. Agente " + agente + ", abriste la boveda.")
elif bloqueado == True:
    print("DERROTA (bloqueo). El sistema se bloqueo por la alarma.")
else:
    print("DERROTA. Te quedaste sin energia o sin tiempo.")

print("Energia final: " + str(energia) + " | Tiempo final: " + str(tiempo) + " | Cerraduras: " + str(cerraduras_abiertas) + "/3")


#Ejercicio 5

print("--- BIENVENIDO A LA ARENA ---")


nombre = input("Nombre del Gladiador: ")
while nombre.isalpha() == False:
    print("Error: Solo se permiten letras.")
    nombre = input("Nombre del Gladiador: ")


vida_jugador = 100        
vida_enemigo = 100        
pociones = 3              
dano_base = 15 
dano_enemigo = 12         
turno_gladiador = True    

print("=== INICIO DEL COMBATE ===")


while vida_jugador > 0 and vida_enemigo > 0:
    print("")
    print(nombre + " (HP: " + str(vida_jugador) + ") vs Enemigo (HP: " + str(vida_enemigo) + ") | Pociones: " + str(pociones))
    print("Elige accion:")
    print("1. Ataque Pesado")
    print("2. Rafaga Veloz")
    print("3. Curar")

    opcion = input("Opcion: ")
    while opcion.isdigit() == False:
        print("Error: Ingrese un numero valido.")
        opcion = input("Opcion: ")

    accion = int(opcion)
    while accion < 1 or accion > 3:
        print("Error: opcion fuera de rango.")
        opcion = input("Opcion: ")
        while opcion.isdigit() == False:
            print("Error: Ingrese un numero valido.")
            opcion = input("Opcion: ")
        accion = int(opcion)


    if accion == 1:
        if vida_enemigo < 20:
            dano_final = dano_base * 1.5   
            print(">> ¡GOLPE CRITICO!")
        else:
            dano_final = dano_base

        vida_enemigo = vida_enemigo - dano_final
        print(f"¡Atacaste al enemigo por {dano_final} puntos de dano!")


    elif accion == 2:
        print(">> ¡Inicias una rafaga de golpes!")
        for golpe in range(3):
            vida_enemigo = vida_enemigo - 5
            print("> Golpe conectado por 5 de dano")


    else:
        if pociones > 0:
            vida_jugador = vida_jugador + 30
            pociones = pociones - 1
            print(">> Bebes una pocion y recuperas 30 puntos de vida.")
        else:
            print("¡No quedan pociones!")


    if vida_enemigo > 0:
        turno_gladiador = False
        vida_jugador = vida_jugador - dano_enemigo
        print("¡El enemigo te ataco por " + str(dano_enemigo) + " puntos de dano!")
        turno_gladiador = True
        print("=== NUEVO TURNO ===")


print("")
if vida_jugador > 0:
    print("¡VICTORIA! " + nombre + " ha ganado la batalla.")
else:
    print("DERROTA. Has caido en combate.")